
import { TruckRecord } from "../types";

// --- HELPERS ---

const getApiKey = () => {
    let apiKey: string | undefined = undefined;
    try {
        if (typeof process !== 'undefined' && process.env) apiKey = process.env.API_KEY;
        if (!apiKey && typeof window !== 'undefined' && (window as any).process?.env) apiKey = (window as any).process.env.API_KEY;
    } catch (e) { console.warn(e); }
    
    if (!apiKey) throw new Error("CRÍTICO: API_KEY no detectada.");
    return apiKey;
};

const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const getResponseSchema = () => ({
    type: "ARRAY",
    items: {
      type: "OBJECT",
      properties: {
        patente: { type: "STRING", description: "La patente o matrícula del camión (ej: AB123CD)." },
        tag: { type: "STRING", description: "El número de TAG, dispositivo de peaje o telepase." },
        dueno: { type: "STRING", description: "Nombre del propietario o dueño del camión." },
        valor: { type: "NUMBER", description: "El valor monetario, monto, flete o cantidad numérica." },
        concepto: { type: "STRING", description: "Breve descripción del servicio o ítem." },
        fecha: { type: "STRING", description: "Fecha del servicio si está disponible (YYYY-MM-DD)." }
      },
      required: ["patente", "dueno", "valor", "concepto"],
    },
});

// --- FALLBACK METHOD (DIRECT REST API) ---
// This acts as a backup engine if the @google/genai library fails to load via CDN
const generateContentFallback = async (apiKey: string, prompt: string, contents: any[], schema: any) => {
    console.warn("Using Fallback REST API for generation...");
    
    const parts = contents.map((c: any) => {
        if (c.mimeType === 'text/plain') return { text: c.data };
        return { inlineData: { mimeType: c.mimeType, data: c.data } };
    });
    
    const requestBody = {
        contents: [{ parts: [...parts, { text: prompt }] }],
        generationConfig: {
            responseMimeType: "application/json",
            responseSchema: schema,
            temperature: 0.1
        }
    };

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
        throw new Error(`Fallback API Error: ${response.status} ${response.statusText}`);
    }

    const json = await response.json();
    return json.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
};

// --- MAIN SERVICE ---

export const processDocuments = async (
  contents: { mimeType: string; data: string }[],
  retries = 3
): Promise<TruckRecord[]> => {
  let lastError: any;
  const apiKey = getApiKey();
  const schema = getResponseSchema();
  const prompt = `
    Actúa como un sistema experto de ERP y contabilidad logística.
    Analiza el documento proporcionado.
    Extrae para cada movimiento: TAG, Patente, Dueño, Valor, Concepto.
    Retorna SOLAMENTE un JSON array válido bajo el esquema provisto.
  `;

  for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        let textResult = "";

        // TRY 1: OFFICIAL SDK
        try {
            const { GoogleGenAI } = await import("@google/genai");
            const ai = new GoogleGenAI({ apiKey });
            
            const sdkParts = contents.map(c => {
                if (c.mimeType === 'text/plain') return { text: c.data };
                return { inlineData: { mimeType: c.mimeType, data: c.data } };
            });

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: { parts: [...sdkParts, { text: prompt }] },
                config: {
                    responseMimeType: "application/json",
                    responseSchema: schema,
                    temperature: 0.1,
                },
            });
            textResult = response.text || "[]";
            
        } catch (importOrSdkErr) {
            console.error("SDK load failed, switching to fallback", importOrSdkErr);
            // TRY 2: FALLBACK REST API
            textResult = await generateContentFallback(apiKey, prompt, contents, schema);
        }

        const data = JSON.parse(textResult) as Omit<TruckRecord, 'id'>[];
        
        return data.map((item, index) => ({
            ...item,
            id: `gen-${Date.now()}-${index}-${Math.random().toString(36).substr(2, 5)}`
        }));

      } catch (error: any) {
        lastError = error;
        console.warn(`Intento ${attempt} fallido:`, error.message);
        
        if (error.message?.includes('401') || error.message?.includes('API_KEY')) {
            throw new Error("Error de autenticación: API Key inválida.");
        }
        if (attempt < retries) await wait(attempt * 2000);
      }
  }
  
  throw new Error(`Error final: ${lastError?.message || 'No se pudo procesar el archivo.'}`);
};

export const convertPdfToData = async (
    contents: { mimeType: string; data: string }[]
): Promise<any[]> => {
    const apiKey = getApiKey();
    const prompt = `
        Analiza este documento. Convierte CUALQUIER tabla en un JSON plano (Array de Objetos).
        Mantén los encabezados originales.
    `;

    try {
        let textResult = "";

        // TRY 1: SDK
        try {
            const { GoogleGenAI } = await import("@google/genai");
            const ai = new GoogleGenAI({ apiKey });
            
            const sdkParts = contents.map(c => ({ inlineData: { mimeType: c.mimeType, data: c.data } }));
            
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: { parts: [...sdkParts, { text: prompt }] },
                config: { responseMimeType: "application/json" },
            });
            textResult = response.text || "[]";
        } catch (e) {
             // TRY 2: Fallback
             // Reuse generic fallback but without specific schema validation
             const parts = contents.map((c: any) => ({ inlineData: { mimeType: c.mimeType, data: c.data } }));
             const requestBody = {
                contents: [{ parts: [...parts, { text: prompt }] }],
                generationConfig: { responseMimeType: "application/json" }
            };
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });
            const json = await response.json();
            textResult = json.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
        }

        return JSON.parse(textResult);
    } catch (e: any) {
        console.error("Conversion error", e);
        return [];
    }
};
